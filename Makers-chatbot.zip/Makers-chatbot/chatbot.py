import random
import json
import pickle
import numpy as np
import nltk
from nltk.stem import WordNetLemmatizer # libreria que permite volver tokens el texto del user
from keras.models import load_model #entrenamiento de la IA
import pandas as pd


inventory = pd.read_csv("inventory_extended.csv")# Cargar inventario


lemmatizer = WordNetLemmatizer() #crea la instancia para la tokenizacion del texto user
intents = json.loads(open('intents_spanish.json', 'r', encoding='utf-8' ).read()) #carga los instents suministrados para el lenguaje

words = pickle.load(open('words.pkl', 'rb')) 
classes = pickle.load(open('classes.pkl', 'rb'))
model = load_model('chatbot_model.h5') #carga las clases encargadas de guardar los modelos

def clean_up_sentence(sentence): 
    sentence_words = nltk.word_tokenize(sentence) # Tokeniza el texto ingresado
    sentence_words = [lemmatizer.lemmatize(word.lower()) for word in sentence_words]#limpia entradas incorrectas
    return sentence_words #devuelve el texto terminado

def bag_of_words(sentence): # Crea un listado de palabras desde el input del usuario
    sentence_words = clean_up_sentence(sentence)
    bag = [0] * len(words) # crea un listado con la longitud de las palabras con valor 0
    for w in sentence_words: # mira una a una las palabras y marca como 1 las que coinciden en el texto con las words del modelo
        for i, word in enumerate(words): 
          if word == w:
              bag[i] = 1 #si encuentra la palabra coincidente la vuelve 1
    return np.array(bag) 

def predict_class(sentence):
    bow = bag_of_words(sentence) 
    res = model.predict(np.array([bow]))[0] #el modelo entrenado encuentra la probabilidad de que coincida con el intent
    ERROR_THRESHOLD = 0.25 
    results = [[i, r] for i, r in enumerate(res) if r > ERROR_THRESHOLD] # crea una lista con probabilidades mayor al 0.25
    results.sort(key=lambda x: x[1], reverse=True) #lo oreganiza de mayor a menor
    return_list = [] 
    for r in results: 
        return_list.append({'intent': classes[r[0]], 'probability': str(r[1])}) # Append the in
    return return_list # devuelve la lista con las probabilidades

def get_response(intents_list, intents_json, user_input):
    if len(intents_list) == 0:
        return "No entendí tu consulta 😅"
    
    tag = intents_list[0]["intent"]
    list_of_intents = intents_json["intents"]

    # Normalizar input del usuario
    user_input_lower = user_input.lower()

    # Intents dinámicos con inventario
    if tag in ["consultar_precio", "consultar_stock", "consultar_caracteristicas"]:
        for _, row in inventory.iterrows():
            product_name = row["name"].lower()
            product_category = row["category"].lower()

            #filtra las coincidencias
            if (any(word in user_input_lower for word in product_name.split()) 
                or product_category in user_input_lower):
                
                if tag == "consultar_precio":
                    return f"{row['name']} cuesta ${row['price']}."
                elif tag == "consultar_stock":
                    return f"Tenemos {row['stock']} unidades de {row['name']} en inventario."
                elif tag == "consultar_caracteristicas":
                    return f"{row['name']}: {row['description']}"
        
        return "No encontré ese producto en el inventario."

    # Intents normales desde el JSON
    for i in list_of_intents:
        if i["tag"] == tag:
            return random.choice(i["responses"])

    return "No entendí tu consulta 😅"
