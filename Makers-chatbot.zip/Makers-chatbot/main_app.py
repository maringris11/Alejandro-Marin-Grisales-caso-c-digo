# main_app.py
import streamlit as st
import pandas as pd
import numpy as np
import time
from pathlib import Path
import random


from chatbot import predict_class, get_response, intents


INVENTORY_CSV = "inventory_extended.csv"


@st.cache_data(ttl=5)  # recarga cada 5 segundos
def cargar_inventari(path: str):#carga los inventarios con ayuda de pandas
    df = pd.read_csv(path)
    df["name_lc"] = df["name"].str.lower()
    df["category_lc"] = df["category"].str.lower()
    return df

def buscar_inventario(df: pd.DataFrame, query: str):
    q = query.strip().lower()#limpia la entrada
    if q == "":
        return df
    coincidencias = df["name_lc"].str.contains(q) | df["category_lc"].str.contains(q)#busca coincidencias con las categorias
    if not coincidencias.any():
        tokens = q.split()
        for t in tokens:
            coincidencias = coincidencias | df["name_lc"].str.contains(t)#an caso de no encontrar coincidencias divide la palabra para volver a buscar
    return df[coincidencias]

def recomendacion(df: pd.DataFrame, user_prefs: dict, top_n=4):
    if not user_prefs:
        df2 = df.copy()
        df2["score"] = df2["stock"] * (df2["price"] / (df2["price"].max() + 1))#pone en alto los productos con mas stock y precios altos
        return df2.sort_values("score", ascending=False).head(top_n)#devuelve lso 4 productos con amyor puntaje segun la formula anterior
    pref_cats = user_prefs.get("categories", [])
    if pref_cats:
        coincidencias = df["category_lc"].isin([c.lower() for c in pref_cats]) #busca los productos de las categorias que se eligieron
        candidates = df[coincidencias]
        if len(candidates) >= top_n:
            return candidates.sort_values(["stock", "price"], ascending=False).head(top_n)
        else:
            resto = df[~coincidencias]
            return pd.concat([
                candidates.sort_values(["stock", "price"], ascending=False),
                resto.sort_values(["stock", "price"], ascending=False)
            ]).head(top_n)
    visto = user_prefs.get("viewed_names", [])
    if visto:
        cats = df[df["name"].isin(visto)]["category_lc"].unique().tolist()
        if len(cats):
            coincidencias = df["category_lc"].isin(cats)
            cand = df[coincidencias].sort_values(["stock", "price"], ascending=False)
            if len(cand) >= top_n:
                return cand.head(top_n)
    return df.sort_values(["stock", "price"], ascending=False).head(top_n)

def metricas(df: pd.DataFrame):
    total_items = int(df["stock"].sum())
    total_value = float((df["stock"] * df["price"]).sum())
    low_stock = df[df["stock"] <= 3]
    by_category = df.groupby("category").agg(
        stock_total=("stock", "sum"),
        inventory_value=("price", "sum")
    ).reset_index()
    return {
        "total_items": total_items,
        "total_value": total_value,
        "low_stock_df": low_stock,
        "by_category": by_category
    }

# ------------------ STREAMLIT CONFIG ------------------
st.set_page_config(page_title="Makers Tech — Tienda Digital", layout="wide", initial_sidebar_state="expanded")

st.header("🛍️ Makers Tech — Plataforma de Productos")
st.markdown("Inventario en tiempo real + Chatbot integrado + Dashboard admin.")

# ------------------ SIDEBAR LOGIN ------------------
st.sidebar.title("Cuenta")
if "username" not in st.session_state:
    st.session_state.username = None
    st.session_state.role = "visitor"
    st.session_state.user_prefs = {}

username = st.sidebar.text_input("Usuario (nombre)", value=st.session_state.get("username") or "")
role = st.sidebar.selectbox("Rol", options=["visitor", "user", "admin"], index=0)
if st.sidebar.button("Iniciar sesión / Aplicar"):
    st.session_state.username = username or "anonimo"
    st.session_state.role = role
    if "user_prefs" not in st.session_state:
        st.session_state.user_prefs = {}
    st.success(f"Sesión iniciada como `{st.session_state.username}` (rol: {st.session_state.role})")


inventory = cargar_inventari(INVENTORY_CSV)

st.sidebar.markdown("## 🤖 Chatbot Asistente")

if "messages" not in st.session_state:
    st.session_state.messages = [] #historial para guardar mensajes
if "first_message" not in st.session_state:
    st.session_state.first_message = True

for message in st.session_state.messages:
    role = "🧑 Usuario" if message["role"] == "user" else "🤖 Bot"
    st.sidebar.markdown(f"**{role}:** {message['content']}")

if st.session_state.first_message:
    st.sidebar.markdown("🤖 Bot: Hola 👋, soy tu asistente de Makers Tech. ¿En qué puedo ayudarte?")
    st.session_state.messages.append(
        {"role": "assistant", "content": "Hola 👋, soy tu asistente de Makers Tech. ¿En qué puedo ayudarte?"}
    )
    st.session_state.first_message = False

user_input = st.sidebar.text_input("Escribe tu mensaje aquí:", key="chat_input")

if st.sidebar.button("Enviar"):
    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})
        insts = predict_class(user_input)
        res = get_response(insts, intents, user_input)
        st.session_state.messages.append({"role": "assistant", "content": res})
        st.rerun()


st.subheader("Productos")

category_filter = st.sidebar.selectbox("Categoría", options=["Todas"] + sorted(inventory["category"].unique().tolist()))
min_price, max_price = st.sidebar.slider(
    "Rango de precio",
    float(inventory["price"].min()),
    float(inventory["price"].max()),
    (float(inventory["price"].min()), float(inventory["price"].max()))
)
in_stock_only = st.sidebar.checkbox("Solo en stock", value=True)

query = st.text_input("Buscar producto", value="", placeholder="Ej: iPhone, laptop, Samsung")
if st.button("Recargar inventario"):
    cargar_inventari.clear()
    inventory = cargar_inventari(INVENTORY_CSV)
    st.success("Inventario recargado")

filtered = inventory.copy()
if query:
    filtered = buscar_inventario(filtered, query)
if category_filter and category_filter != "Todas":
    filtered = filtered[filtered["category"] == category_filter]
filtered = filtered[(filtered["price"] >= min_price) & (filtered["price"] <= max_price)]
if in_stock_only:
    filtered = filtered[filtered["stock"] > 0]

cols_per_row = 3
product_cols = st.columns(cols_per_row)

i = 0
for idx, row in filtered.reset_index(drop=True).iterrows():
    col = product_cols[i % cols_per_row]
    with col:
        st.image("https://via.placeholder.com/300x180.png?text=Producto", width=300)
        st.write(f"**{row['name']}**")
        st.write(f"_{row['category']}_")
        st.write(f"Precio: **${row['price']}**")
        st.write(f"Stock: **{row['stock']}** unidades")
        st.write(row["description"])
    i += 1


st.divider()
st.subheader("Productos Recomendados para Ti")
user_prefs = st.session_state.get("user_prefs", {})
cats = sorted(inventory["category"].unique().tolist())
sel_cats = st.multiselect(
    "Selecciona tus categorías favoritas (para recomendaciones)",
    options=cats,
    default=user_prefs.get("categories", [])
)
st.session_state.user_prefs["categories"] = sel_cats
recommended = recomendacion(inventory, st.session_state.user_prefs, top_n=4)
for _, r in recommended.iterrows():
    st.write(f"- **{r['name']}** — ${r['price']} — Stock: {r['stock']}")


if st.session_state.get("role") == "admin":
    st.divider()
    st.subheader(" Dashboard Administrativo")
    metrics = metricas(inventory)
    c1, c2, c3 = st.columns(3)
    c1.metric("Total unidades (stock)", metrics["total_items"])
    c2.metric("Valor total inventario", f"${metrics['total_value']:.2f}")
    c3.metric("Productos en bajo stock", len(metrics["low_stock_df"]))

    st.bar_chart(metrics["by_category"].set_index("category")["stock_total"])
    st.table(metrics["low_stock_df"][["id","name","category","stock"]].reset_index(drop=True))
